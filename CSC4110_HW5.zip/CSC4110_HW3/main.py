import random
import string
from datetime import datetime

# Ammar Alameri
# Date: February 15, 2024
# Revision: 1

class DataCollector:
    def generate_username(self):
        """Generate a random username."""
        return ''.join(random.choices(string.ascii_lowercase, k=8))

    def generate_password(self):
        """Generate a random password."""
        return ''.join(random.choices(string.ascii_letters + string.digits, k=10))

    def generate_birthdate(self):
        """Generate a random birthdate."""
        return datetime(random.randint(1970, 2000), random.randint(1, 12), random.randint(1, 28))

    def generate_address(self):
        """Generate a random address."""
        return f"{random.randint(1, 999)} {random.choice(['Main', 'Oak', 'Elm'])} St, {random.choice(['New York', 'Los Angeles', 'Chicago'])}"

    def generate_social_security_number(self):
        """Generate a random social security number."""
        return ''.join(random.choices(string.digits, k=9))

    def generate_product_purchased(self):
        """Generate a random product purchased."""
        products = ["ID-trxdfn", "ID-pqwert", "ID-lkjasd"]
        return random.choice(products)

    def generate_salesperson(self):
        """Generate a random salesperson."""
        salespeople = ["John", "Alice", "Amar"]  
        return random.choice(salespeople)

    def generate_user_record(self):
        """Generate a random user record."""
        return {
            "username": self.generate_username(),
            "password": self.generate_password(),
            "birthdate": self.generate_birthdate(),
            "address": self.generate_address(),
            "social_security_number": self.generate_social_security_number(),
            "productPurchased": self.generate_product_purchased(),
            "salesperson": self.generate_salesperson()
        }

class KeyValueStore:
    def __init__(self):
        """Initialize the key-value store."""
        self.store = {}

    def add_user_record(self, user_id, user_record):
        """Add a user record to the key-value store."""
        self.store[user_id] = user_record

    def get_user_record(self, user_id):
        """Retrieve a user record from the key-value store."""
        return self.store.get(user_id, None)

class SearchEngine:
    def __init__(self, store):
        """Initialize the search engine."""
        self.store = store

    def search_by_state(self, state):
        """Search for users by state."""
        return [record for record in self.store.values() if state.lower() in record['address'].lower()]

    def search_by_salesperson(self, salesperson):
        """Search for users by salesperson."""
        return [record for record in self.store.values() if salesperson.lower() == record['salesperson'].lower()]

collector = DataCollector()
key_value_store = KeyValueStore()

# Generate 10 user records and store them in the key-value store
for i in range(10):
    user_id = f'user_{i}'
    user_record = collector.generate_user_record()
    key_value_store.add_user_record(user_id, user_record)

# Search for users in New York and handled by Amar
search_engine = SearchEngine(key_value_store.store)
users_in_ny = search_engine.search_by_state('New York')
users_handled_by_amar = search_engine.search_by_salesperson('Amar')  

# Print the results
print("Users in New York:")
for user in users_in_ny:
    print(user)

print("\nUsers handled by Amar:")
for user in users_handled_by_amar:
    print(user)
