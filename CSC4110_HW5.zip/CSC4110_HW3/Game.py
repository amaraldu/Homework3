# Treasure Game Simulation
# Date: February 15, 2024
# Ammar Alameri
00
import random

class PirateTreasureGame:
    def __init__(self, initial_bank_amount=1000):
        self.treasure_chest = []
        self.bank = initial_bank_amount

    def populate_treasure_chest(self, num_items):
        items = ["gold coin", "silver coin", "diamond", "ruby", "sapphire", "emerald"]
        self.treasure_chest = random.choices(items, k=num_items)

    def place_wager(self, amount):
        """Place a wager"""
        if amount <= self.bank:
            self.bank -= amount
            return True
        else:
            print("You don't have enough funds to place this wager.")
            return False

    def spin_treasure_chest(self):
        """Spin the treasure chest to grab an item"""
        if not self.treasure_chest:
            print("Treasure chest is empty. Populate it first.")
            return

        item = random.choice(self.treasure_chest)
        return item

# Instantiate the game
pirate_game = PirateTreasureGame()

# Populate treasure chest with 5 items
pirate_game.populate_treasure_chest(5)

# Start playing
while pirate_game.bank > 0:
    print("\nYour current bank balance:", pirate_game.bank)
    wager = int(input("Place your wager: "))
    if pirate_game.place_wager(wager):
        grabbed_item = pirate_game.spin_treasure_chest()
        if grabbed_item:
            print("You grabbed a", grabbed_item)
            pirate_game.bank += 100  # Assuming each item is worth 100 coins
        else:
            print("No items left in the treasure chest.")
            break
    else:
        break

print("Game over. Your final bank balance:", pirate_game.bank)
