import random
import string
# Date: February 15, 2024
# Ammar Alameri

def generate_password(length=12):
    characters = string.ascii_letters + string.digits + string.punctuation
    return ''.join(random.choice(characters) for _ in range(length))

def is_acceptable(password):
    # Check if password contains at least one special symbol
    has_special_symbol = any(char in string.punctuation for char in password)
    
    # Check if password is not a dictionary word
    is_not_dictionary_word = password.lower() not in dictionary_words
    
    return has_special_symbol and is_not_dictionary_word

def simulate_passwords(iterations=40):
    accepted_passwords = []
    
    for _ in range(iterations):
        password = generate_password()
        if is_acceptable(password):
            accepted_passwords.append(password)
    
    return accepted_passwords

# Example usage
dictionary_words = set(['example', 'dictionary', 'words'])
accepted_passwords = simulate_passwords()
print("Accepted Passwords:")
for password in accepted_passwords:
    print(password)
